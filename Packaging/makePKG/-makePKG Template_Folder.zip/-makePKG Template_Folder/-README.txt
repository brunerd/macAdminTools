makePKG README
#Joel Bruner

1. The parent folder name is the name of the package (spaces not recommended)
2. "payload" folder is the _root_ directory, recreate the _exact_ folder structure needed to install the payload
3. If using "scripts" folder, use only the file names "preinstall" and "postinstall"
4. run makePKG.command and the finished .pkg file will be in "build" folder

